#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define ARRAY_SIZE 10000 // Adjust the array size as needed

int *myArray;
int myArrayLength;
int numThreads;

struct ThreadInfo {
    int threadID;
    int startIndex;
    int endIndex;
    int privateOnesCount;
};

void *countOnes(void *arg) {
    struct ThreadInfo *data = (struct ThreadInfo *)arg;
    data->privateOnesCount = 0;

    for (int i = data->startIndex; i < data->endIndex; i++) {
        if (myArray[i] == 1) {
            data->privateOnesCount++;
        }
    }

    pthread_exit(NULL);
}

void generateRandomArray() {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < myArrayLength; i++) {
        myArray[i] = rand() % 6;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number_of_threads>\n", argv[0]);
        return -1;
    }

    numThreads = atoi(argv[1]);

    myArrayLength = ARRAY_SIZE;
    myArray = (int *)malloc(myArrayLength * sizeof(int));
    generateRandomArray();

    printf("Array size: %d\n", myArrayLength);
    printf("Number of threads: %d\n", numThreads);

    int correctCounts = 0;
    struct ThreadInfo threadData[numThreads];
    pthread_t threads[numThreads];

    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < numThreads; j++) {
            threadData[j].threadID = j;
            threadData[j].startIndex = j * (myArrayLength / numThreads);
            threadData[j].endIndex = (j + 1) * (myArrayLength / numThreads);
            if (j == numThreads - 1) {
                threadData[j].endIndex = myArrayLength;
            }
            pthread_create(&threads[j], NULL, countOnes, (void *)&threadData[j]);
        }

        for (int j = 0; j < numThreads; j++) {
            pthread_join(threads[j], NULL);
        }

        int totalOnesCount = 0;
        for (int j = 0; j < numThreads; j++) {
            totalOnesCount += threadData[j].privateOnesCount;
        }

        int actualCount = 0;
        for (int j = 0; j < myArrayLength; j++) {
            if (myArray[j] == 1) {
                actualCount++;
            }
        }

        if (totalOnesCount == actualCount) {
            correctCounts++;
        }
    }

    printf("\nNumber of times the program returns the right answer: %d\n", correctCounts);

    free(myArray);

    return 0;
}
