#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <stdint.h>

#define ARRAY_SIZE 10000 // Adjust the array size as needed
#define CACHE_LINE_SIZE 64 // Assume a cache line size of 64 bytes (hypothetical)

struct ThreadPrivateData {
    int privateOnesCount;
    char padding[CACHE_LINE_SIZE - sizeof(int)]; // Padding to fill the cache line
};

int *myArray;
int myArrayLength;
int numThreads;

void *countOnes(void *arg) {
    struct ThreadPrivateData *data = (struct ThreadPrivateData *)arg;
    data->privateOnesCount = 0;

    // Rest of the code remains the same as before
    // ...
}

// Other functions remain unchanged

int main(int argc, char *argv[]) {
    // Remaining parts of main function remain unchanged

    struct ThreadPrivateData threadData[numThreads];

    // Rest of the code remains the same as before
    // ...
}
