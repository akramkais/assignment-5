#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define SMALL_ARRAY_SIZE 1000
#define MEDIUM_ARRAY_SIZE 1000000
#define LARGE_ARRAY_SIZE 1000000000

int *myArray;
int myArrayLength;
int totalCount = 0;
int numThreads;

struct ThreadInfo {
    int threadID;
    int startIndex;
    int endIndex;
};

void *countOnes(void *arg) {
    struct ThreadInfo *data = (struct ThreadInfo *)arg;
    int localCount = 0;

    for (int i = data->startIndex; i < data->endIndex; i++) {
        if (myArray[i] == 1) {
            localCount++;
        }
    }

    __sync_fetch_and_add(&totalCount, localCount);

    pthread_exit(NULL);
}

void generateRandomArray() {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < myArrayLength; i++) {
        myArray[i] = rand() % 6;
    }
}

int main() {
    int sizes[] = {SMALL_ARRAY_SIZE, MEDIUM_ARRAY_SIZE, LARGE_ARRAY_SIZE};
    int threadCounts[] = {1, 2, 4, 32};

    for (int i = 0; i < 3; i++) {
        myArrayLength = sizes[i];
        myArray = (int *)malloc(myArrayLength * sizeof(int));
        generateRandomArray();

        printf("Array size: %d\n", myArrayLength);

        for (int j = 0; j < 4; j++) {
            numThreads = threadCounts[j];
            printf("Number of threads: %d\n", numThreads);

            totalCount = 0;
            pthread_t threads[numThreads];
            struct ThreadInfo threadInfo[numThreads];

            clock_t startTime = clock();

            for (int k = 0; k < numThreads; k++) {
                threadInfo[k].threadID = k;
                threadInfo[k].startIndex = k * (myArrayLength / numThreads);
                threadInfo[k].endIndex = (k + 1) * (myArrayLength / numThreads);
                if (k == numThreads - 1) {
                    threadInfo[k].endIndex = myArrayLength;
                }
                pthread_create(&threads[k], NULL, countOnes, (void *)&threadInfo[k]);
            }

            for (int k = 0; k < numThreads; k++) {
                pthread_join(threads[k], NULL);
            }

            clock_t endTime = clock();
            double executionTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
            printf("Execution time: %f seconds\n\n", executionTime);
        }

        free(myArray);
    }

    return 0;
}
